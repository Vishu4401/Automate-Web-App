package selenium.programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Automation_Web {
	
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\vmb44\\Desktop\\chromedriver.exe");
    WebDriver driver = new ChromeDriver(); // this intializes the chrome web browser
    
	driver.get("https://demo.automationtesting.in/Register.html");
    driver.manage().window().maximize();
    Thread.sleep(4000);
    driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Vishwanath");
    Thread.sleep(4000);
    driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Bagali");
    Thread.sleep(4000);
    //driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("8765461684");
    //driver.findElement(By.partialLinkText("
    driver.findElement(By.xpath("//textarea[@rows='3']")).sendKeys("Bengaluru, Karnataka");
    Thread.sleep(4000);
    driver.findElement(By.xpath("//input[@type='email']")).sendKeys("vmb@gmail.com");
    Thread.sleep(4000);
    driver.findElement(By.xpath("//input[@type='tel']")).sendKeys("7418529630");
    Thread.sleep(4000);
    WebElement radio1 = driver.findElement(By.xpath("//input[@value='Male']"));	
    radio1.click();
    Thread.sleep(4000);
    WebElement radio2 = driver.findElement(By.xpath("//input[@value='Male']"));	
    radio2.click();
    Thread.sleep(4000);
    
   driver.findElement(By.id("checkbox1")).click();
   driver.findElement(By.id("checkbox2")).click();;
   Select fruits = new Select(driver.findElement(By.xpath("//label[@class='col-md-3 col-xs-3 col-sm-3']")));
	fruits.selectByVisibleText("English");

    Thread.sleep(4000);
    driver.close();

	}


}

